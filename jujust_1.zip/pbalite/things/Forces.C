#include "Forces.h"
#include <iostream>

Vector GravityForce::computeForce(Vector position, Vector velocity)
{
    return gravity;
}
